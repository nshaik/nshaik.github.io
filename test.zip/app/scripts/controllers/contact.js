'use strict';

angular.module('contact', [])

.controller('ContactCtrl', ['$scope', '$routeParams', '$rootScope', '$location', function ($scope, $routeParams, $rootScope, $location) {
    $rootScope.currentNav = $location.path();
}]);
