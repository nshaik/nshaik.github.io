'use strict';

angular.module('work', [])

.controller('WorkCtrl', ['$scope', '$routeParams', '$rootScope', '$location', function ($scope, $routeParams, $rootScope, $location) {
    $rootScope.currentNav = $location.path();
	$scope.works = [
		{img:"images/yeoman.png", alt:"yeoman.png"},
		{img:"http://www.zerodesigns.in/images/zerodesigns/graphic-design.jpg", alt:"yeoman.png"},
		{img:"http://nbpdblog.files.wordpress.com/2012/07/vectorstock_754291.jpg", alt:"yeoman.png"},
		{img:"http://www.marketingengineers.com/wp-content/uploads/2013/09/Graphic-Design.jpg", alt:"yeoman.png"},
		{img:"http://www.queenswebdesignandgraphics.com/img/designGraphics.jpg", alt:"yeoman.png"},
		{img:"http://www.99hdwallpaper.com/easter/wallpapers/easter-graphics.jpg", alt:"yeoman.png"}
	]
}]);
