'use strict';

angular.module('home', [])

.controller('HomeCtrl', ['$scope', '$routeParams', '$rootScope', '$location', function ($scope, $routeParams, $rootScope, $location) {
    $rootScope.currentNav = $location.path();
}]);
